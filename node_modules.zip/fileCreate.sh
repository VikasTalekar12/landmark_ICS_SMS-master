#!/bin/bash

cat > snfile.txt